# Code and Libraries

This folder contains all 20 Python scripts, arranged by responsibility, plus the dependency list and the script catalogue.

## Install

From the project root, install PyTorch using the official command selector for your machine (CPU or the correct CUDA version): https://pytorch.org/get-started/locally/ . Then run:

```bash
pip install -r Code/requirements.txt
```

## Run convention

Run commands from the project root. Each script locates the project root itself, so the current working directory should not affect its data paths.

The ordinary dataset indexers are:

```bash
python Code/src/data_preparation/create_manifests.py
python Code/src/data_preparation/create_asvspoof_dev_manifest.py
```

The latest speaker-disjoint training and evaluation commands are documented in the project-root README. Do not start those commands until the original `itw_speaker_train.csv`, `itw_speaker_val.csv`, and `itw_speaker_test.csv` have been recovered. The uploaded source tree does not contain the script that generates them.

## Contents

- `src/data_preparation/` — manifest creation and external benchmark preparation.
- `src/training/` — the two CNN training pipelines and their audio/feature Dataset implementations.
- `src/evaluation/` — held-out test, same-corpus dev, external benchmark, and per-speaker evaluation.
- `src/inference/` — single-audio prediction scripts.
- `src/diagnostics/` — audio, feature, duplicate, and score diagnostics.
- `requirements.txt` — runtime libraries. PyTorch is installed separately to match the local compute environment.
