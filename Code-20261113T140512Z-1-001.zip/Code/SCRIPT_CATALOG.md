# Python Script Catalog

| Folder | Script | Purpose |
|---|---|---|
| `data_preparation/` | `create_manifests.py` | Indexes ASVspoof train audio using its protocol and indexes In-the-Wild train/validation/test folders. |
| `data_preparation/` | `create_asvspoof_dev_manifest.py` | Creates the ASVspoof2019 LA dev manifest from its protocol and FLAC files. |
| `data_preparation/` | `prepare_wavefake_benchmark.py` | Selects matched LJSpeech utterances and downloads generated versions for seven WaveFake generators. |
| `training/` | `train_cnn.py` | Earlier mixed CNN training pipeline; creates the mixed checkpoint. |
| `training/` | `train_cnn_speaker_disjoint.py` | Main speaker-disjoint CNN training pipeline; expects the three `itw_speaker_*.csv` manifests. |
| `evaluation/` | `evaluate_asvspoof_dev.py` | Evaluates the older baseline checkpoint on ASVspoof dev. |
| `evaluation/` | `evaluate_mixed_asvspoof_dev.py` | Evaluates the mixed checkpoint on ASVspoof dev. |
| `evaluation/` | `evaluate_mixed_itw_val.py` | Evaluates the mixed checkpoint on In-the-Wild validation. |
| `evaluation/` | `evaluate_mixed_itw_test.py` | Evaluates the mixed checkpoint on In-the-Wild test. |
| `evaluation/` | `evaluate_speaker_disjoint.py` | Evaluates the final speaker-disjoint checkpoint on held-out In-the-Wild speakers. |
| `evaluation/` | `evaluate_speaker_model_asvspoof_dev.py` | Evaluates the speaker-disjoint checkpoint on ASVspoof dev. |
| `evaluation/` | `evaluate_wavefake_external.py` | Evaluates the speaker-disjoint checkpoint on the prepared WaveFake subset. |
| `evaluation/` | `analyze_speaker_performance.py` | Computes metrics separately for each held-out speaker. |
| `inference/` | `predict_audio.py` | Runs the mixed model on the two configured user audio examples. |
| `inference/` | `predict_audio_backup.py` | Earlier/backup inference implementation. |
| `diagnostics/` | `audit_audio.py` | Samples manifest recordings and checks readability/sample rate/duration. |
| `diagnostics/` | `check_audio_duplicates.py` | Hashes In-the-Wild train/validation audio to find duplicate files and overlap. |
| `diagnostics/` | `test_features.py` | Checks feature extraction for sample manifest recordings. |
| `diagnostics/` | `diagnose_asvspoof.py` | Diagnoses the older baseline model's score direction on ASVspoof training samples. |
| `diagnostics/` | `diagnose_model.py` | Diagnoses the older baseline model's score distribution on In-the-Wild validation. |

## Feature extraction location

There is no independent `spectrograms.py`. The log-Mel feature pipeline is implemented inside `AudioDataset.__getitem__` in both training modules. The WaveFake evaluator also has an equivalent feature extraction function for its long recordings.
