# Model weights

All three checkpoints from the uploaded ZIP are preserved.

- `best_cnn_speaker_disjoint.pt` — checkpoint epoch 3; used by the latest speaker-disjoint evaluation logs. This is the primary checkpoint from the final pipeline represented in the archive.
- `best_cnn_mixed.pt` — checkpoint epoch 5; earlier mixed training experiment.
- `best_cnn.pt` — checkpoint epoch 1; earlier baseline run with poor recorded validation AUC (0.2105). Retained for experiment history, not recommended as the final model.

Checkpoint metadata includes model state, epoch, validation metrics, and feature configuration (16 kHz, 4-second audio, 64 Mel bins, FFT 400, hop 160).
