# Results and logs

The original training logs, evaluation logs, CSV metrics, and WaveFake predictions are preserved in `logs/`.

Most important results recorded in the supplied logs:

- Speaker-disjoint In-the-Wild test: 8,966 recordings; ROC-AUC 0.992780; EER 2.40%; accuracy 98.32%; F1 98.79% at threshold 0.5.
- ASVspoof2019 LA dev evaluation with the speaker-disjoint checkpoint: ROC-AUC 0.986056; EER 5.82%; accuracy 80.57%; precision 34.47% at threshold 0.5. This is a same-corpus dev-partition evaluation, not an independent external test.
- WaveFake external benchmark: overall ROC-AUC 0.662993; EER 37.79%; accuracy 50% at threshold 0.5. The logs show all generated fake samples were classified as real at that fixed threshold. This is an important limitation.

The logs are historical outputs from the machine where the experiments ran; their original absolute paths are retained as provenance and will not exist on a different computer.
