from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from train_cnn_speaker_disjoint import (
    AudioCNN,
    AudioDataset,
    DEVICE,
    load_manifest,
    BATCH_SIZE,
)

ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT = ROOT / "results/checkpoints/best_cnn_speaker_disjoint.pt"


def main():
    rows = load_manifest("asvspoof_dev.csv")

    labels_manifest = np.asarray([r["label"] for r in rows], dtype=int)
    if set(np.unique(labels_manifest)) != {0, 1}:
        raise ValueError("Expected both real (1) and spoof (0) labels.")

    checkpoint = torch.load(
        CHECKPOINT,
        map_location=DEVICE,
        weights_only=False,
    )

    model = AudioCNN().to(DEVICE)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    loader = DataLoader(
        AudioDataset(rows, training=False),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    all_labels = []
    all_scores = []

    with torch.no_grad():
        for batch_idx, (features, labels) in enumerate(loader, start=1):
            logits = model(features.to(DEVICE))
            scores = torch.sigmoid(logits).cpu().numpy().reshape(-1)

            all_labels.extend(labels.numpy().reshape(-1).astype(int))
            all_scores.extend(scores)

            if batch_idx % 100 == 0:
                print(f"Processed {len(all_labels)}/{len(rows)} recordings")

    y = np.asarray(all_labels, dtype=int)
    scores = np.asarray(all_scores, dtype=float)

    if len(y) != len(rows):
        raise RuntimeError("Evaluated sample count differs from manifest.")

    predictions = (scores >= 0.5).astype(int)

    auc = roc_auc_score(y, scores)
    fpr, tpr, _ = roc_curve(y, scores)
    fnr = 1 - tpr
    idx = np.argmin(np.abs(fpr - fnr))
    eer = (fpr[idx] + fnr[idx]) / 2

    print("\n=== SPEAKER-DISJOINT MODEL: ASVSPOOF2019 LA DEV ===")
    print("Checkpoint:", CHECKPOINT.name)
    print("Checkpoint epoch:", checkpoint["epoch"])
    print("Threshold: 0.5 (fixed)")
    print("Recordings:", len(y))
    print("Real recordings:", int((y == 1).sum()))
    print("Spoof recordings:", int((y == 0).sum()))

    print("\nROC-AUC:", round(float(auc), 6))
    print("EER:", round(float(eer), 6), f"({eer * 100:.2f}%)")

    print("\nMetrics at threshold 0.5:")
    print("Accuracy:", round(float(accuracy_score(y, predictions)), 4))
    print("Precision:", round(float(precision_score(
        y, predictions, zero_division=0
    )), 4))
    print("Recall:", round(float(recall_score(
        y, predictions, zero_division=0
    )), 4))
    print("F1:", round(float(f1_score(y, predictions, zero_division=0)), 4))

    print("\nConfusion matrix")
    print("Rows = actual [spoof, real]; columns = predicted [spoof, real]")
    print(confusion_matrix(y, predictions, labels=[0, 1]))

    print("\nThis is a held-out partition of a training corpus,")
    print("not an independent-dataset evaluation.")


if __name__ == "__main__":
    main()
