from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from train_cnn_speaker_disjoint import (
    AudioCNN,
    AudioDataset,
    DEVICE,
    load_manifest,
    BATCH_SIZE,
)

ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT_PATH = (
    ROOT / "results" / "checkpoints" / "best_cnn_speaker_disjoint.pt"
)


def main():
    # Load split metadata and verify speaker separation before testing.
    train_rows = load_manifest("itw_speaker_train.csv")
    val_rows = load_manifest("itw_speaker_val.csv")
    test_rows = load_manifest("itw_speaker_test.csv")

    def get_speakers(rows, name):
        speakers = {row.get("speaker", "").strip() for row in rows}
        if "" in speakers:
            raise ValueError(f"Missing speaker metadata in {name} manifest.")
        return speakers

    train_speakers = get_speakers(train_rows, "train")
    val_speakers = get_speakers(val_rows, "validation")
    test_speakers = get_speakers(test_rows, "test")

    assert not train_speakers & val_speakers, "Train/validation speaker overlap"
    assert not train_speakers & test_speakers, "Train/test speaker overlap"
    assert not val_speakers & test_speakers, "Validation/test speaker overlap"

    # Confirm that both classes are present in the test manifest.
    y_manifest = np.array([row["label"] for row in test_rows], dtype=int)
    if set(np.unique(y_manifest)) != {0, 1}:
        raise ValueError("Test manifest must contain both labels 0 and 1.")

    # Load the checkpoint selected using validation AUC.
    checkpoint = torch.load(
        CHECKPOINT_PATH,
        map_location=DEVICE,
        weights_only=False,
    )

    model = AudioCNN().to(DEVICE)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    loader = DataLoader(
        AudioDataset(test_rows, training=False),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    labels_all = []
    scores_all = []

    # One evaluation pass over the held-out test recordings.
    with torch.no_grad():
        for batch_idx, (features, labels) in enumerate(loader, start=1):
            logits = model(features.to(DEVICE))
            scores = torch.sigmoid(logits).cpu().numpy().reshape(-1)

            labels_all.extend(labels.numpy().reshape(-1))
            scores_all.extend(scores)

            if batch_idx % 50 == 0:
                print(
                    f"Processed {len(labels_all)}/{len(test_rows)} recordings",
                    flush=True,
                )

    y = np.asarray(labels_all, dtype=int)
    scores = np.asarray(scores_all, dtype=float)

    if len(y) != len(test_rows):
        raise RuntimeError("Evaluated sample count does not match test manifest.")

    # Fixed operating threshold: 0.5, unchanged from the existing evaluation.
    predictions = (scores >= 0.5).astype(int)

    auc = roc_auc_score(y, scores)
    fpr, tpr, _ = roc_curve(y, scores)
    fnr = 1.0 - tpr
    eer_idx = np.argmin(np.abs(fpr - fnr))
    eer = (fpr[eer_idx] + fnr[eer_idx]) / 2.0

    print("\n" + "=" * 60)
    print("SPEAKER-DISJOINT HELD-OUT TEST RESULTS")
    print("=" * 60)
    print("Checkpoint:", CHECKPOINT_PATH.name)
    print("Selected checkpoint epoch:", checkpoint["epoch"])
    print("Device:", DEVICE)
    print("Training speakers:", len(train_speakers))
    print("Validation speakers:", len(val_speakers))
    print("Held-out test speakers:", len(test_speakers))
    print("Test recordings:", len(y))
    print("Real recordings (label 1):", int((y == 1).sum()))
    print("Fake/spoof recordings (label 0):", int((y == 0).sum()))

    print("\nThreshold-independent / ROC metrics:")
    print(f"ROC-AUC: {auc:.6f}")
    print(f"EER:     {eer:.6f} ({eer * 100:.2f}%)")

    print("\nMetrics at the fixed threshold of 0.5:")
    print(f"Accuracy:  {accuracy_score(y, predictions):.4f}")
    print(
        f"Precision: {precision_score(y, predictions, zero_division=0):.4f}"
    )
    print(f"Recall:    {recall_score(y, predictions, zero_division=0):.4f}")
    print(f"F1:        {f1_score(y, predictions, zero_division=0):.4f}")

    print("\nConfusion matrix")
    print("Rows = actual [fake/spoof, real]")
    print("Cols = predicted [fake/spoof, real]")
    print(confusion_matrix(y, predictions, labels=[0, 1]))

    print("\nMean predicted real score:")
    print(f"Actual real recordings: {scores[y == 1].mean():.4f}")
    print(f"Actual fake/spoof recordings: {scores[y == 0].mean():.4f}")

    print("\nEvaluation complete. Do not use these test results to tune the model.")


if __name__ == "__main__":
    main()
