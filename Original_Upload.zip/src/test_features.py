import csv
import random
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
MANIFESTS = ROOT / "data" / "manifests"
random.seed(42)

for name in ["asvspoof_train.csv", "itw_train.csv"]:
    path = MANIFESTS / name

    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    print(f"\n{name}")

    for label in [1, 0]:
        candidates = [r for r in rows if int(r["label"]) == label]
        row = random.choice(candidates)

        audio, sr = sf.read(row["file_path"], dtype="float32")

        if audio.ndim == 2:
            audio = audio.mean(axis=1)

        if sr != 16000:
            audio = librosa.resample(
                audio, orig_sr=sr, target_sr=16000
            )

        # Use a consistent 4-second input.
        target_length = 4 * 16000
        if len(audio) > target_length:
            start = (len(audio) - target_length) // 2
            audio = audio[start:start + target_length]
        else:
            audio = np.pad(
                audio, (0, target_length - len(audio))
            )

        mel = librosa.feature.melspectrogram(
            y=audio,
            sr=16000,
            n_fft=400,
            hop_length=160,
            n_mels=64,
            fmin=20,
            fmax=8000,
            power=2.0,
        )

        log_mel = librosa.power_to_db(mel, ref=np.max)

        print(
            f"label={label} | "
            f"audio={audio.shape} | "
            f"spectrogram={log_mel.shape} | "
            f"finite={np.isfinite(log_mel).all()} | "
            f"range=({log_mel.min():.1f}, "
            f"{log_mel.max():.1f}) dB"
        )
