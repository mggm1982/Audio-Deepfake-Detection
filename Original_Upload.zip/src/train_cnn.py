import csv
import random
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
)

ROOT = Path(__file__).resolve().parents[1]
MANIFESTS = ROOT / "data" / "manifests"
CHECKPOINT_DIR = ROOT / "results" / "checkpoints"

SR = 16000
DURATION = 4
NUM_SAMPLES = SR * DURATION
N_FFT = 400
HOP_LENGTH = 160
N_MELS = 64

BATCH_SIZE = 32
EPOCHS = 5
LEARNING_RATE = 1e-3
NUM_WORKERS = 4
SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_manifest(filename):
    path = MANIFESTS / filename
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    for row in rows:
        row["label"] = int(row["label"])

    return rows


# librosa creates the mel filter bank once. PyTorch performs
# the spectrogram calculation for each audio file.
MEL_FILTER = torch.from_numpy(
    librosa.filters.mel(
        sr=SR,
        n_fft=N_FFT,
        n_mels=N_MELS,
        fmin=20,
        fmax=8000,
        dtype=np.float32,
    )
)

WINDOW = torch.hann_window(N_FFT)


class AudioDataset(Dataset):
    def __init__(self, rows, training=False):
        self.rows = rows
        self.training = training

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        path = row["file_path"]

        try:
            audio, sr = sf.read(path, dtype="float32")
        except Exception as exc:
            raise RuntimeError(f"Could not read audio: {path}") from exc

        # Convert stereo to mono if necessary.
        if audio.ndim == 2:
            audio = audio.mean(axis=1)

        # Standardize sample rate if a file differs from 16 kHz.
        if sr != SR:
            audio = librosa.resample(
                audio, orig_sr=sr, target_sr=SR
            ).astype(np.float32)

        audio = torch.from_numpy(np.asarray(audio, dtype=np.float32))

        # Random crop during training; center crop during validation.
        if len(audio) > NUM_SAMPLES:
            if self.training:
                start = random.randint(0, len(audio) - NUM_SAMPLES)
            else:
                start = (len(audio) - NUM_SAMPLES) // 2
            audio = audio[start:start + NUM_SAMPLES]
        elif len(audio) < NUM_SAMPLES:
            audio = torch.nn.functional.pad(
                audio, (0, NUM_SAMPLES - len(audio))
            )

        # Power spectrogram -> Mel spectrogram -> log-dB.
        spec = torch.stft(
            audio,
            n_fft=N_FFT,
            hop_length=HOP_LENGTH,
            win_length=N_FFT,
            window=WINDOW,
            center=True,
            pad_mode="reflect",
            return_complex=True,
        ).abs().square()

        mel = MEL_FILTER @ spec
        log_mel = 10.0 * torch.log10(mel.clamp_min(1e-10))
        log_mel = log_mel - log_mel.max()
        log_mel = log_mel.clamp(min=-80.0, max=0.0)

        # Map approximately [-80, 0] dB to [-1, 1].
        features = (log_mel + 40.0) / 40.0
        features = features.unsqueeze(0)  # (1, 64, 401)

        label = torch.tensor(row["label"], dtype=torch.float32)
        return features, label


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels, out_channels,
                kernel_size=3, padding=1, bias=False
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
        )

    def forward(self, x):
        return self.block(x)


class AudioCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            ConvBlock(1, 16),
            ConvBlock(16, 32),
            ConvBlock(32, 64),
            ConvBlock(64, 96),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(0.30),
            nn.Linear(96, 1),
        )

    def forward(self, x):
        return self.classifier(self.features(x)).squeeze(1)


def calculate_metrics(labels, scores):
    labels = np.asarray(labels, dtype=np.int64)
    scores = np.asarray(scores, dtype=np.float64)
    predictions = (scores >= 0.5).astype(np.int64)

    auc = roc_auc_score(labels, scores)
    fpr, tpr, thresholds = roc_curve(labels, scores)
    fnr = 1.0 - tpr
    eer_index = np.argmin(np.abs(fpr - fnr))
    eer = (fpr[eer_index] + fnr[eer_index]) / 2.0

    return {
        "auc": auc,
        "eer": eer,
        "accuracy": accuracy_score(labels, predictions),
        "precision": precision_score(
            labels, predictions, zero_division=0
        ),
        "recall": recall_score(
            labels, predictions, zero_division=0
        ),
        "f1": f1_score(labels, predictions, zero_division=0),
    }


def run_epoch(model, loader, criterion, optimizer=None):
    training = optimizer is not None
    model.train(training)

    total_loss = 0.0
    all_labels = []
    all_scores = []

    context = torch.enable_grad if training else torch.no_grad

    with context():
        for step, (features, labels) in enumerate(loader, start=1):
            features = features.to(DEVICE, non_blocking=True)
            labels = labels.to(DEVICE, non_blocking=True)

            if training:
                optimizer.zero_grad(set_to_none=True)

            logits = model(features)
            loss = criterion(logits, labels)

            if training:
                loss.backward()
                optimizer.step()

            total_loss += loss.item() * len(labels)
            all_labels.extend(labels.detach().cpu().numpy())
            all_scores.extend(
                torch.sigmoid(logits).detach().cpu().numpy()
            )

            if training and step % 100 == 0:
                print(
                    f"  Batch {step}/{len(loader)} "
                    f"| loss={loss.item():.4f}",
                    flush=True,
                )

    metrics = calculate_metrics(all_labels, all_scores)
    metrics["loss"] = total_loss / len(loader.dataset)
    return metrics


def main():
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

    asv_rows = load_manifest("asvspoof_train.csv")
    itw_rows = load_manifest("itw_train.csv")
    train_rows = asv_rows + itw_rows
    val_rows = load_manifest("itw_val.csv")

    train_labels = np.array([r["label"] for r in train_rows])
    counts = np.bincount(train_labels, minlength=2)

    if np.any(counts == 0):
        raise ValueError(f"Training set is missing a class: {counts}")

    print("Device:", DEVICE)
    if DEVICE.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))

    print(f"Training files: {len(train_rows):,}")
    print(f"  Real: {counts[1]:,}")
    print(f"  Spoof: {counts[0]:,}")
    print(f"Validation files: {len(val_rows):,}")
    print("Labels: 1 = real, 0 = fake/spoof")
    print("Validation: In-the-Wild; test split will not be used.")
    print()

    # Balance each source-label group independently.
    # Groups: ASV-real, ASV-fake, InTheWild-real, InTheWild-fake.
    from collections import Counter

    group_keys = [
        (row.get("source", "unknown"), row["label"])
        for row in train_rows
    ]
    group_counts = Counter(group_keys)

    if len(group_counts) < 4:
        raise ValueError(
            f"Expected four source-label groups, found: {group_counts}"
        )

    sample_weights = [
        1.0 / group_counts[key] for key in group_keys
    ]
    sampler = WeightedRandomSampler(
        weights=torch.as_tensor(sample_weights, dtype=torch.double),
        num_samples=len(train_rows),
        replacement=True,
    )

    print("Source-label groups:")
    for key, count in sorted(group_counts.items()):
        print(f"  source={key[0]}, label={key[1]}: {count:,}")

    train_loader = DataLoader(
        AudioDataset(train_rows, training=True),
        batch_size=BATCH_SIZE,
        sampler=sampler,
        num_workers=NUM_WORKERS,
        pin_memory=(DEVICE.type == "cuda"),
        persistent_workers=(NUM_WORKERS > 0),
    )

    val_loader = DataLoader(
        AudioDataset(val_rows, training=False),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=(DEVICE.type == "cuda"),
        persistent_workers=(NUM_WORKERS > 0),
    )

    model = AudioCNN().to(DEVICE)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=LEARNING_RATE, weight_decay=1e-4
    )

    best_auc = -1.0
    checkpoint_path = CHECKPOINT_DIR / "best_cnn_mixed.pt"

    for epoch in range(1, EPOCHS + 1):
        print(f"\n{'=' * 60}")
        print(f"Epoch {epoch}/{EPOCHS}")

        train_metrics = run_epoch(
            model, train_loader, criterion, optimizer
        )
        val_metrics = run_epoch(
            model, val_loader, criterion
        )

        print(
            f"Train | loss={train_metrics['loss']:.4f} "
            f"| AUC={train_metrics['auc']:.4f} "
            f"| F1={train_metrics['f1']:.4f}"
        )
        print(
            f"Val   | loss={val_metrics['loss']:.4f} "
            f"| AUC={val_metrics['auc']:.4f} "
            f"| EER={val_metrics['eer']:.4f} "
            f"| Acc={val_metrics['accuracy']:.4f} "
            f"| Precision={val_metrics['precision']:.4f} "
            f"| Recall={val_metrics['recall']:.4f} "
            f"| F1={val_metrics['f1']:.4f}"
        )

        if val_metrics["auc"] > best_auc:
            best_auc = val_metrics["auc"]
            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "val_metrics": val_metrics,
                    "config": {
                        "sample_rate": SR,
                        "duration_seconds": DURATION,
                        "n_mels": N_MELS,
                        "n_fft": N_FFT,
                        "hop_length": HOP_LENGTH,
                    },
                },
                checkpoint_path,
            )
            print(f"Saved best checkpoint: {checkpoint_path}")

    print(f"\nTraining complete. Best validation AUC: {best_auc:.4f}")
    print(f"Checkpoint: {checkpoint_path}")


if __name__ == "__main__":
    main()
