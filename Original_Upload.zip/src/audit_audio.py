import csv
import random
from pathlib import Path

import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_DIR = ROOT / "data" / "manifests"
random.seed(42)

manifests = [
    "asvspoof_train.csv",
    "itw_train.csv",
    "itw_val.csv",
    "itw_test.csv",
]

for manifest_name in manifests:
    manifest = MANIFEST_DIR / manifest_name

    print("\n" + "=" * 70)
    print(manifest_name)

    if not manifest.exists():
        print(f"ERROR: Manifest not found: {manifest}")
        continue

    with manifest.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    groups = {}
    for row in rows:
        groups.setdefault(int(row["label"]), []).append(row)

    for label, label_name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
        group = groups.get(label, [])
        print(f"\n{label_name}: {len(group):,} indexed files")

        for row in random.sample(group, min(5, len(group))):
            path = Path(row["file_path"])

            try:
                info = sf.info(str(path))
                print(
                    f"  {path.name}: "
                    f"{info.samplerate} Hz, "
                    f"{info.channels} channel(s), "
                    f"{info.duration:.2f} sec"
                )
            except Exception as e:
                print(f"  ERROR: {path} -- {e}")
