import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from train_cnn_speaker_disjoint import (
    AudioCNN,
    AudioDataset,
    DEVICE,
    load_manifest,
    BATCH_SIZE,
)

ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT = ROOT / "results/checkpoints/best_cnn_speaker_disjoint.pt"
OUTPUT = ROOT / "results/logs/per_speaker_metrics.csv"


def main():
    rows = load_manifest("itw_speaker_test.csv")

    if any(not row.get("speaker", "").strip() for row in rows):
        raise ValueError("Missing speaker IDs in the test manifest.")

    checkpoint = torch.load(
        CHECKPOINT,
        map_location=DEVICE,
        weights_only=False,
    )

    model = AudioCNN().to(DEVICE)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    loader = DataLoader(
        AudioDataset(rows, training=False),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    all_labels = []
    all_scores = []

    with torch.no_grad():
        for i, (features, labels) in enumerate(loader, start=1):
            logits = model(features.to(DEVICE))
            scores = torch.sigmoid(logits).cpu().numpy().reshape(-1)

            all_labels.extend(labels.numpy().reshape(-1).astype(int))
            all_scores.extend(scores)

            if i % 50 == 0:
                print(f"Processed {len(all_labels)}/{len(rows)} recordings")

    if len(all_labels) != len(rows):
        raise RuntimeError("Prediction count differs from test manifest.")

    # Preserve the manifest order: the DataLoader is not shuffled.
    grouped = defaultdict(lambda: {"labels": [], "scores": []})

    for row, label, score in zip(rows, all_labels, all_scores):
        speaker = row["speaker"].strip()
        grouped[speaker]["labels"].append(int(label))
        grouped[speaker]["scores"].append(float(score))

    results = []

    for speaker, data in sorted(grouped.items()):
        y = np.asarray(data["labels"], dtype=int)
        scores = np.asarray(data["scores"], dtype=float)
        pred = (scores >= 0.5).astype(int)

        cm = confusion_matrix(y, pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel()

        # AUC and EER require both real and spoof recordings.
        if len(np.unique(y)) == 2:
            auc = float(roc_auc_score(y, scores))
            fpr, tpr, _ = roc_curve(y, scores)
            fnr = 1.0 - tpr
            idx = np.argmin(np.abs(fpr - fnr))
            eer = float((fpr[idx] + fnr[idx]) / 2.0)
        else:
            auc = float("nan")
            eer = float("nan")

        results.append({
            "speaker": speaker,
            "recordings": len(y),
            "real_count": int((y == 1).sum()),
            "spoof_count": int((y == 0).sum()),
            "auc": auc,
            "eer": eer,
            "accuracy": float(accuracy_score(y, pred)),
            "precision_real": float(
                precision_score(y, pred, zero_division=0)
            ),
            "recall_real": float(
                recall_score(y, pred, zero_division=0)
            ),
            "f1_real": float(f1_score(y, pred, zero_division=0)),
            "spoof_detection_rate": (
                float(tn / (tn + fp)) if (tn + fp) else float("nan")
            ),
            "spoof_missed_as_real": int(fp),
            "real_flagged_as_spoof": int(fn),
            "real_correct": int(tp),
            "spoof_correct": int(tn),
        })

    print("\n=== HELD-OUT SPEAKER-BY-SPEAKER RESULTS ===")
    print("Checkpoint:", CHECKPOINT.name, "| epoch:", checkpoint["epoch"])
    print("Threshold: 0.5 (fixed)")
    print("Higher AUC and lower EER are generally better.\n")

    header = (
        f"{'Speaker':<22} {'N':>5} {'Real':>5} {'Spoof':>5} "
        f"{'AUC':>8} {'EER%':>8} {'Acc%':>8} "
        f"{'SpoofDet%':>10} {'Missed':>7} {'RealFP':>7}"
    )
    print(header)
    print("-" * len(header))

    for r in results:
        print(
            f"{r['speaker'][:22]:<22} "
            f"{r['recordings']:>5} "
            f"{r['real_count']:>5} "
            f"{r['spoof_count']:>5} "
            f"{r['auc'] * 100:>7.2f} "
            f"{r['eer'] * 100:>7.2f} "
            f"{r['accuracy'] * 100:>7.2f} "
            f"{r['spoof_detection_rate'] * 100:>9.2f} "
            f"{r['spoof_missed_as_real']:>7} "
            f"{r['real_flagged_as_spoof']:>7}"
        )

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)

    print(f"\nSaved detailed per-speaker metrics to: {OUTPUT}")
    print("These results are diagnostic; do not tune on the held-out test set.")


if __name__ == "__main__":
    main()
