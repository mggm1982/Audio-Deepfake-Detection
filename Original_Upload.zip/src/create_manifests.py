from pathlib import Path
import csv
import re

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "manifests"

ASV_ROOT = RAW / "LA (1)" / "LA"
ASV_AUDIO = ASV_ROOT / "ASVspoof2019_LA_train" / "flac"
ASV_PROTOCOL = (
    ASV_ROOT
    / "ASVspoof2019_LA_cm_protocols"
    / "ASVspoof2019.LA.cm.train.trn.txt"
)

ITW_ROOT = RAW / "release_in_the_wild"

AUDIO_EXTENSIONS = {".wav", ".flac", ".mp3", ".ogg", ".m4a"}


def write_manifest(name, rows):
    path = OUT / name
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["file_path", "label", "split", "source"]
        )
        writer.writeheader()
        writer.writerows(rows)
    return path


def count_labels(rows):
    real = sum(int(r["label"]) == 1 for r in rows)
    fake = sum(int(r["label"]) == 0 for r in rows)
    return real, fake


def create_asvspoof_manifest():
    if not ASV_AUDIO.is_dir():
        raise FileNotFoundError(f"Audio folder not found: {ASV_AUDIO}")
    if not ASV_PROTOCOL.is_file():
        raise FileNotFoundError(f"Protocol not found: {ASV_PROTOCOL}")

    rows = []
    missing = []
    unknown = []
    seen = set()

    with ASV_PROTOCOL.open(encoding="utf-8") as f:
        for line_number, line in enumerate(f, start=1):
            parts = line.split()
            if not parts:
                continue

            label_tokens = [
                token.lower()
                for token in parts
                if token.lower() in {"bonafide", "spoof"}
            ]
            if not label_tokens:
                unknown.append((line_number, line.strip()))
                continue

            label = 1 if label_tokens[-1] == "bonafide" else 0

            # Find the protocol token corresponding to an actual audio file.
            candidates = [
                token for token in parts
                if re.fullmatch(r"LA_T_\d+", token)
            ]
            if not candidates:
                candidates = [parts[1]] if len(parts) >= 2 else []

            if not candidates:
                unknown.append((line_number, line.strip()))
                continue

            file_id = candidates[0]
            audio_path = ASV_AUDIO / f"{file_id}.flac"

            if not audio_path.is_file():
                missing.append(str(audio_path))
                continue

            if file_id in seen:
                continue
            seen.add(file_id)

            rows.append({
                "file_path": str(audio_path.resolve()),
                "label": label,
                "split": "train",
                "source": "ASVspoof2019_LA",
            })

    write_manifest("asvspoof_train.csv", rows)
    real, fake = count_labels(rows)

    print("\nASVspoof training manifest")
    print(f"  Total indexed: {len(rows):,}")
    print(f"  Real:          {real:,}")
    print(f"  Spoof:         {fake:,}")
    print(f"  Missing files: {len(missing):,}")
    print(f"  Unrecognized protocol lines: {len(unknown):,}")

    if missing:
        print("  First missing paths:")
        for p in missing[:5]:
            print("   ", p)
    if unknown:
        print("  First unrecognized protocol lines:")
        for line_no, line in unknown[:3]:
            print(f"    line {line_no}: {line}")

    if not rows:
        raise RuntimeError(
            "No ASVspoof entries were indexed. Check protocol format."
        )

    return rows


def create_itw_manifest(split):
    split_dir = ITW_ROOT / split
    if not split_dir.is_dir():
        raise FileNotFoundError(f"In-the-Wild split not found: {split_dir}")

    rows = []
    missing_classes = []

    for class_name, label in [("real", 1), ("fake", 0)]:
        class_dir = split_dir / class_name

        if not class_dir.is_dir():
            missing_classes.append(str(class_dir))
            continue

        for audio_path in sorted(class_dir.rglob("*")):
            if not audio_path.is_file():
                continue
            if audio_path.suffix.lower() not in AUDIO_EXTENSIONS:
                continue

            rows.append({
                "file_path": str(audio_path.resolve()),
                "label": label,
                "split": split,
                "source": "InTheWild",
            })

    write_manifest(f"itw_{split}.csv", rows)
    real, fake = count_labels(rows)

    print(f"\nIn-the-Wild {split} manifest")
    print(f"  Total indexed: {len(rows):,}")
    print(f"  Real:          {real:,}")
    print(f"  Fake:          {fake:,}")

    if missing_classes:
        print("  Missing class directories:")
        for p in missing_classes:
            print("   ", p)

    if not rows:
        raise RuntimeError(f"No audio files indexed in ITW {split}.")

    return rows


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    print("Project root:", ROOT)
    print("Manifest output:", OUT)

    all_rows = {"asvspoof_train": create_asvspoof_manifest()}

    for split in ("train", "val", "test"):
        all_rows[f"itw_{split}"] = create_itw_manifest(split)

    summary_path = OUT / "dataset_summary.txt"
    with summary_path.open("w", encoding="utf-8") as f:
        f.write("Audio deepfake detector: dataset index summary\n\n")
        for name, rows in all_rows.items():
            real, fake = count_labels(rows)
            f.write(
                f"{name}: total={len(rows)}, real={real}, fake={fake}\n"
            )

        f.write(
            "\nLabels: 1=real/bona fide; 0=fake/spoof.\n"
            "Initial experiment: ASVspoof train; ITW val for validation; "
            "ITW test held out for final evaluation.\n"
            "ITW train is reserved for a possible separate experiment.\n"
        )

    print("\nSummary saved to:", summary_path)
    print("\nManifest creation complete.")


if __name__ == "__main__":
    main()
