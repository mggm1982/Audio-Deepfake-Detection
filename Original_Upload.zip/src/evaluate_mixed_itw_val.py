import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score, roc_curve, accuracy_score,
    precision_score, recall_score, f1_score,
    confusion_matrix,
)

from train_cnn import AudioCNN, AudioDataset, DEVICE, load_manifest, BATCH_SIZE

checkpoint_path = "results/checkpoints/best_cnn_mixed.pt"
checkpoint = torch.load(
    checkpoint_path, map_location=DEVICE, weights_only=False
)

model = AudioCNN().to(DEVICE)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

rows = load_manifest("itw_val.csv")
loader = DataLoader(
    AudioDataset(rows, training=False),
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
)

labels_all = []
scores_all = []

with torch.no_grad():
    for features, labels in loader:
        logits = model(features.to(DEVICE))
        scores = torch.sigmoid(logits).cpu().numpy().reshape(-1)
        labels_all.extend(labels.numpy().reshape(-1))
        scores_all.extend(scores)

y = np.asarray(labels_all, dtype=int)
scores = np.asarray(scores_all, dtype=float)
predictions = (scores >= 0.5).astype(int)

auc = roc_auc_score(y, scores)
fpr, tpr, thresholds = roc_curve(y, scores)
fnr = 1 - tpr
i = np.argmin(np.abs(fpr - fnr))
eer = (fpr[i] + fnr[i]) / 2

print("\n=== MIXED MODEL: IN THE WILD VALIDATION ===")
print("Checkpoint epoch:", checkpoint["epoch"])
print("Samples:", len(y))
print("ROC-AUC:", round(float(auc), 6))
print("EER:", round(float(eer), 6))
print("Approximate EER threshold:", round(float(thresholds[i]), 6))

print("\nMetrics at threshold 0.5:")
print("Accuracy:", round(accuracy_score(y, predictions), 4))
print("Precision:", round(precision_score(y, predictions, zero_division=0), 4))
print("Recall:", round(recall_score(y, predictions, zero_division=0), 4))
print("F1:", round(f1_score(y, predictions, zero_division=0), 4))
print("Confusion matrix [[fake->fake, fake->real], [real->fake, real->real]]:")
print(confusion_matrix(y, predictions, labels=[0, 1]))

for label, name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
    s = scores[y == label]
    print(f"\n{name}: count={len(s)}")
    print("  Mean score:", round(float(s.mean()), 6))
    print("  Median score:", round(float(np.median(s)), 6))
    print("  Min / max:", round(float(s.min()), 6), "/", round(float(s.max()), 6))
    print("  Fraction >= 0.5:", round(float((s >= 0.5).mean()), 4))
