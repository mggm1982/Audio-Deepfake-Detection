from pathlib import Path
import sys

import numpy as np
import librosa
import soundfile as sf
import torch
import torch.nn as nn

from train_cnn import (
    SR, DURATION, NUM_SAMPLES, N_FFT, HOP_LENGTH, N_MELS,
    MEL_FILTER, WINDOW, AudioCNN, DEVICE, ROOT,
)

CHECKPOINT = ROOT / "results" / "checkpoints" / "best_cnn_mixed.pt"


def extract_features(path):
    audio, sr = sf.read(str(path), dtype="float32")

    if audio.ndim == 2:
        audio = audio.mean(axis=1)

    if sr != SR:
        audio = librosa.resample(
            audio, orig_sr=sr, target_sr=SR
        ).astype(np.float32)

    audio = torch.from_numpy(np.asarray(audio, dtype=np.float32))

    if len(audio) > NUM_SAMPLES:
        start = (len(audio) - NUM_SAMPLES) // 2
        audio = audio[start:start + NUM_SAMPLES]
    elif len(audio) < NUM_SAMPLES:
        audio = torch.nn.functional.pad(
            audio, (0, NUM_SAMPLES - len(audio))
        )

    spec = torch.stft(
        audio,
        n_fft=N_FFT,
        hop_length=HOP_LENGTH,
        win_length=N_FFT,
        window=WINDOW,
        center=True,
        pad_mode="reflect",
        return_complex=True,
    ).abs().square()

    mel = MEL_FILTER @ spec
    log_mel = 10.0 * torch.log10(mel.clamp_min(1e-10))
    log_mel = log_mel - log_mel.max()
    log_mel = log_mel.clamp(min=-80.0, max=0.0)
    features = ((log_mel + 40.0) / 40.0).unsqueeze(0)

    return features.unsqueeze(0).to(DEVICE)


def main():
    files = [
        ROOT / "data" / "my_audio" / "my_real_voice_original.wav",
        ROOT / "data" / "my_audio" / "my_ai_voice.wav",
    ]

    for path in files:
        if not path.is_file():
            print(f"ERROR: File not found: {path}")
            sys.exit(1)

    model = AudioCNN().to(DEVICE)
    checkpoint = torch.load(
        CHECKPOINT, map_location=DEVICE, weights_only=False
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print(f"Device: {DEVICE}")
    print(f"Checkpoint epoch: {checkpoint.get('epoch', 'unknown')}")
    print("\n--- AUDIO PREDICTIONS ---")

    with torch.no_grad():
        for path in files:
            features = extract_features(path)
            score = torch.sigmoid(model(features)).item()
            verdict = "REAL" if score >= 0.5 else "FAKE/SPOOF"

            print(f"\nFile: {path.name}")
            print(f"Real-class score: {score:.6f}")
            print(f"Prediction at threshold 0.5: {verdict}")


if __name__ == "__main__":
    main()
