import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score

from train_cnn import (
    AudioCNN, AudioDataset, DEVICE, load_manifest, BATCH_SIZE
)

random.seed(42)
np.random.seed(42)

checkpoint = torch.load(
    "results/checkpoints/best_cnn.pt",
    map_location=DEVICE,
    weights_only=False,
)

model = AudioCNN().to(DEVICE)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

rows = load_manifest("asvspoof_train.csv")
sample_size = min(1000, len(rows))
sample_rows = random.sample(rows, sample_size)

loader = DataLoader(
    AudioDataset(sample_rows, training=False),
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
)

all_labels = []
all_scores = []

with torch.no_grad():
    for features, labels in loader:
        logits = model(features.to(DEVICE))
        scores = torch.sigmoid(logits).cpu().numpy()
        all_labels.extend(labels.numpy())
        all_scores.extend(scores)

labels = np.asarray(all_labels, dtype=int)
scores = np.asarray(all_scores)

print("Checkpoint epoch:", checkpoint["epoch"])
print("Samples evaluated:", len(labels))
print("Label counts:", np.unique(labels, return_counts=True))

for label, name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
    class_scores = scores[labels == label]
    print(f"\n{name} mean score:",
          round(float(class_scores.mean()), 4))
    print(f"{name} median score:",
          round(float(np.median(class_scores)), 4))

print("\nASVspoof training-subset AUC:",
      round(roc_auc_score(labels, scores), 4))
print("Inverted-score AUC:",
      round(roc_auc_score(labels, 1 - scores), 4))
