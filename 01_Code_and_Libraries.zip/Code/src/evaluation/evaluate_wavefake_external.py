# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

from pathlib import Path
import csv

import librosa
import numpy as np
import soundfile as sf
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from training.train_cnn_speaker_disjoint import (
    SR,
    NUM_SAMPLES,
    N_FFT,
    HOP_LENGTH,
    MEL_FILTER,
    WINDOW,
    AudioCNN,
    DEVICE,
    ROOT,
)

CHECKPOINT = ROOT / "Model Weights" / "best_cnn_speaker_disjoint.pt"
MANIFEST = ROOT / "Additional Evaluation Data" / "WaveFake" / "wavefake_benchmark" / "pairs.csv"
THRESHOLD = 0.5


def load_audio(path):
    audio, sr = sf.read(str(path), dtype="float32")

    if audio.ndim == 2:
        audio = audio.mean(axis=1)

    if sr != SR:
        audio = librosa.resample(
            audio, orig_sr=sr, target_sr=SR
        ).astype(np.float32)

    return audio


def extract_features(segment):
    segment = torch.from_numpy(
        np.asarray(segment, dtype=np.float32)
    )

    if len(segment) < NUM_SAMPLES:
        segment = F.pad(segment, (0, NUM_SAMPLES - len(segment)))

    spec = torch.stft(
        segment,
        n_fft=N_FFT,
        hop_length=HOP_LENGTH,
        win_length=N_FFT,
        window=WINDOW,
        center=True,
        pad_mode="reflect",
        return_complex=True,
    ).abs().square()

    mel = MEL_FILTER @ spec
    log_mel = 10.0 * torch.log10(mel.clamp_min(1e-10))
    log_mel = log_mel - log_mel.max()
    log_mel = log_mel.clamp(min=-80.0, max=0.0)

    features = ((log_mel + 40.0) / 40.0).unsqueeze(0)
    return features.unsqueeze(0).to(DEVICE)


def score_file(model, path):
    audio = load_audio(path)

    if len(audio) < NUM_SAMPLES:
        starts = [0]
    else:
        last_start = len(audio) - NUM_SAMPLES
        starts = list(range(0, last_start + 1, SR))
        if starts[-1] != last_start:
            starts.append(last_start)

    scores = []

    for start in starts:
        segment = audio[start:start + NUM_SAMPLES]
        features = extract_features(segment)

        with torch.no_grad():
            score = torch.sigmoid(model(features)).item()

        scores.append(score)

    return {
        "duration_seconds": len(audio) / SR,
        "windows": len(scores),
        "window_scores": scores,
        "mean_score": float(np.mean(scores)),
        "median_score": float(np.median(scores)),
    }


def calculate_metrics(labels, scores):
    labels = np.asarray(labels, dtype=int)
    scores = np.asarray(scores, dtype=float)
    predictions = (scores >= THRESHOLD).astype(int)

    auc = roc_auc_score(labels, scores)
    fpr, tpr, thresholds = roc_curve(labels, scores)
    fnr = 1.0 - tpr
    eer_index = int(np.nanargmin(np.abs(fpr - fnr)))
    eer = float((fpr[eer_index] + fnr[eer_index]) / 2.0)

    # Matrix order: actual [FAKE, REAL], predicted [FAKE, REAL].
    tn, fp, fn, tp = confusion_matrix(
        labels, predictions, labels=[0, 1]
    ).ravel()

    return {
        "n_real": int(np.sum(labels == 1)),
        "n_fake": int(np.sum(labels == 0)),
        "roc_auc": float(auc),
        "eer": eer,
        "accuracy_at_0.5": float(accuracy_score(labels, predictions)),
        "precision_real_at_0.5": float(
            precision_score(labels, predictions, zero_division=0)
        ),
        "recall_real_at_0.5": float(
            recall_score(labels, predictions, zero_division=0)
        ),
        "f1_real_at_0.5": float(
            f1_score(labels, predictions, zero_division=0)
        ),
        "tn_fake_correct": int(tn),
        "fp_fake_called_real": int(fp),
        "fn_real_called_fake": int(fn),
        "tp_real_correct": int(tp),
        "eer_threshold": float(thresholds[eer_index]),
    }


def main():
    if not CHECKPOINT.is_file():
        raise FileNotFoundError(f"Checkpoint missing: {CHECKPOINT}")
    if not MANIFEST.is_file():
        raise FileNotFoundError(f"Manifest missing: {MANIFEST}")

    with MANIFEST.open(newline="", encoding="utf-8") as file:
        pairs = list(csv.DictReader(file))

    if not pairs:
        raise RuntimeError("The benchmark manifest is empty.")

    checkpoint = torch.load(
        CHECKPOINT, map_location=DEVICE, weights_only=False
    )
    model = AudioCNN().to(DEVICE)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print("=" * 72)
    print("WAVEFAKE EXTERNAL BENCHMARK")
    print("=" * 72)
    print(f"Checkpoint: {CHECKPOINT.name}")
    print(f"Checkpoint epoch: {checkpoint.get('epoch', 'unknown')}")
    print(f"Device: {DEVICE}")
    print(f"Threshold: {THRESHOLD} (unchanged)")
    print("Higher score = more likely REAL.")
    print(f"Matched pairs: {len(pairs)}")
    print("Scoring audio files; this may take several minutes.")

    # Score each distinct original only once.
    real_results = {}
    for row in pairs:
        utterance_id = row["utterance_id"]
        if utterance_id not in real_results:
            real_path = ROOT / row["real_path"]
            if not real_path.is_file():
                raise FileNotFoundError(real_path)

            real_results[utterance_id] = score_file(model, real_path)

            if len(real_results) % 10 == 0:
                print(
                    f"Original recordings scored: "
                    f"{len(real_results)}/{len(set(r['utterance_id'] for r in pairs))}"
                )

    # Score every generated file and create per-file records.
    detail_rows = []
    results_by_generator = {}

    for index, row in enumerate(pairs, 1):
        utterance_id = row["utterance_id"]
        generator = row["generator"]
        fake_path = ROOT / row["fake_path"]

        if not fake_path.is_file():
            raise FileNotFoundError(fake_path)

        real_result = real_results[utterance_id]
        fake_result = score_file(model, fake_path)

        for actual, path, result in [
            ("REAL", row["real_path"], real_result),
            ("FAKE", row["fake_path"], fake_result),
        ]:
            detail_rows.append({
                "utterance_id": utterance_id,
                "generator": generator,
                "actual": actual,
                "file": path,
                "duration_seconds": result["duration_seconds"],
                "windows": result["windows"],
                "window_scores": ";".join(
                    f"{s:.8f}" for s in result["window_scores"]
                ),
                "mean_real_score": result["mean_score"],
                "median_real_score": result["median_score"],
                "prediction_at_0.5": (
                    "REAL" if result["mean_score"] >= THRESHOLD else "FAKE"
                ),
            })

        bucket = results_by_generator.setdefault(
            generator, {"labels": [], "scores": []}
        )
        bucket["labels"].extend([1, 0])
        bucket["scores"].extend([
            real_result["mean_score"],
            fake_result["mean_score"],
        ])

        if index % 50 == 0 or index == len(pairs):
            print(f"Generated recordings scored: {index}/{len(pairs)}")

    # Per-generator and overall metrics.
    summary_rows = []
    all_labels = []
    all_scores = []

    for generator, bucket in sorted(results_by_generator.items()):
        metrics = calculate_metrics(bucket["labels"], bucket["scores"])
        summary_rows.append({"generator": generator, **metrics})
        all_labels.extend(bucket["labels"])
        all_scores.extend(bucket["scores"])

    overall = calculate_metrics(all_labels, all_scores)
    summary_rows.append({"generator": "OVERALL_MICRO", **overall})

    output_dir = ROOT / "Results" / "logs"
    output_dir.mkdir(parents=True, exist_ok=True)

    detail_path = output_dir / "wavefake_external_predictions.csv"
    with detail_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=detail_rows[0].keys())
        writer.writeheader()
        writer.writerows(detail_rows)

    summary_path = output_dir / "wavefake_external_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=summary_rows[0].keys())
        writer.writeheader()
        writer.writerows(summary_rows)

    print("\n" + "=" * 100)
    print("RESULTS")
    print("=" * 100)
    print(
        f"{'Generator':35s} {'AUC':>8s} {'EER':>8s} "
        f"{'Acc@.5':>8s} {'Prec':>8s} {'Recall':>8s} {'F1':>8s}"
    )

    for row in summary_rows:
        print(
            f"{row['generator']:35s} "
            f"{row['roc_auc']:8.4f} "
            f"{row['eer']:8.4f} "
            f"{row['accuracy_at_0.5']:8.4f} "
            f"{row['precision_real_at_0.5']:8.4f} "
            f"{row['recall_real_at_0.5']:8.4f} "
            f"{row['f1_real_at_0.5']:8.4f}"
        )

    print("\nConfusion counts at threshold 0.5 (overall):")
    print(f"  Fake correctly called fake: {overall['tn_fake_correct']}")
    print(f"  Fake incorrectly called real: {overall['fp_fake_called_real']}")
    print(f"  Real incorrectly called fake: {overall['fn_real_called_fake']}")
    print(f"  Real correctly called real: {overall['tp_real_correct']}")

    print(f"\nDetailed predictions: {detail_path.relative_to(ROOT)}")
    print(f"Summary metrics:      {summary_path.relative_to(ROOT)}")
    print("\nNote: EER is estimated from the ROC curve; it is not the fixed 0.5 threshold.")
    print("Overall results reuse each original across generators, so observations")
    print("are paired and should not be treated as fully independent samples.")


if __name__ == "__main__":
    main()
