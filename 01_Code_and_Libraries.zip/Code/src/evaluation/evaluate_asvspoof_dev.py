# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from training.train_cnn import (
    AudioCNN, AudioDataset, DEVICE, load_manifest, BATCH_SIZE
)

torch.manual_seed(42)

checkpoint = torch.load(
    ROOT / "Model Weights" / "best_cnn.pt",
    map_location=DEVICE,
    weights_only=False,
)

model = AudioCNN().to(DEVICE)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

rows = load_manifest("asvspoof_dev.csv")

loader = DataLoader(
    AudioDataset(rows, training=False),
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
)

all_labels = []
all_scores = []

with torch.no_grad():
    for batch_index, (features, labels) in enumerate(loader):
        logits = model(features.to(DEVICE))
        scores = torch.sigmoid(logits).cpu().numpy().reshape(-1)

        all_labels.extend(labels.numpy().reshape(-1))
        all_scores.extend(scores)

        if (batch_index + 1) % 100 == 0:
            print(f"Evaluated {(batch_index + 1) * BATCH_SIZE:,} samples")

y = np.asarray(all_labels, dtype=int)
scores = np.asarray(all_scores, dtype=float)
predictions = (scores >= 0.5).astype(int)

auc = roc_auc_score(y, scores)
fpr, tpr, thresholds = roc_curve(y, scores)
fnr = 1 - tpr
eer_index = np.argmin(np.abs(fpr - fnr))
eer = (fpr[eer_index] + fnr[eer_index]) / 2
eer_threshold = thresholds[eer_index]

print("\n========== ASVSPOOF DEV RESULTS ==========")
print("Checkpoint epoch:", checkpoint["epoch"])
print("Total evaluated:", len(y))
print("Real samples:", int((y == 1).sum()))
print("Fake/spoof samples:", int((y == 0).sum()))

print("\nROC-AUC:", round(float(auc), 4))
print("Inverted-score ROC-AUC:", round(float(1 - auc), 4))
print("Equal Error Rate (EER):", round(float(eer), 4))
print("Approximate EER threshold:", round(float(eer_threshold), 4))

print("\n--- At threshold 0.5 (score >= 0.5 means real) ---")
print("Accuracy:", round(accuracy_score(y, predictions), 4))
print("Precision:", round(precision_score(y, predictions, zero_division=0), 4))
print("Recall:", round(recall_score(y, predictions, zero_division=0), 4))
print("F1:", round(f1_score(y, predictions, zero_division=0), 4))
print("Confusion matrix [[true fake predicted fake/real],"
      " [true real predicted fake/real]]:")
print(confusion_matrix(y, predictions, labels=[0, 1]))

for label, name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
    class_scores = scores[y == label]
    print(f"\n{name}:")
    print("  Mean score:", round(float(class_scores.mean()), 4))
    print("  Median score:", round(float(np.median(class_scores)), 4))
    print("  Fraction >= 0.5:",
          round(float((class_scores >= 0.5).mean()), 4))
