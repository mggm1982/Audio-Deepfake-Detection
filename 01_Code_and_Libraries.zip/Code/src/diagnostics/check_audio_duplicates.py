# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

import csv
import hashlib
from pathlib import Path
from collections import defaultdict

MANIFESTS = {
    "train": ROOT / "Manifests" / "itw_train.csv",
    "val": ROOT / "Manifests" / "itw_val.csv",
}

def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

hashes = {}
missing = defaultdict(list)

for split, manifest in MANIFESTS.items():
    with manifest.open(newline="") as f:
        rows = list(csv.DictReader(f))

    split_hashes = defaultdict(list)
    print(f"\nHashing {split}: {len(rows):,} files")

    for i, row in enumerate(rows, 1):
        path = Path(row["file_path"]).expanduser()

        if not path.is_file():
            missing[split].append(str(path))
            continue

        digest = file_hash(path)
        split_hashes[digest].append(str(path))

        if i % 5000 == 0:
            print(f"  Processed {i:,}/{len(rows):,}")

    hashes[split] = split_hashes

    duplicate_groups = [
        paths for paths in split_hashes.values() if len(paths) > 1
    ]
    print(f"Unique file hashes: {len(split_hashes):,}")
    print(f"Duplicate groups within {split}: {len(duplicate_groups):,}")

    for group in duplicate_groups[:5]:
        print("  Duplicate examples:")
        for p in group:
            print("   ", p)

train_hashes = set(hashes["train"])
val_hashes = set(hashes["val"])
overlap = train_hashes & val_hashes

print("\n=== TRAIN vs VALIDATION ===")
print("Exact audio hashes shared:", len(overlap))

for digest in list(overlap)[:10]:
    print("\nShared hash:", digest)
    for split in ("train", "val"):
        for p in hashes[split][digest]:
            print(f"  {split}: {p}")

print("\nMissing files:", {k: len(v) for k, v in missing.items()})
for split, paths in missing.items():
    for p in paths[:5]:
        print(f"  {split}: {p}")
