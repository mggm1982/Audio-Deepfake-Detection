# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score

from training.train_cnn import (
    AudioCNN, AudioDataset, DEVICE, load_manifest, BATCH_SIZE
)

checkpoint_path = ROOT / "Model Weights" / "best_cnn.pt"
checkpoint = torch.load(
    checkpoint_path, map_location=DEVICE, weights_only=False
)

model = AudioCNN().to(DEVICE)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

rows = load_manifest("itw_val.csv")
loader = DataLoader(
    AudioDataset(rows, training=False),
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=(DEVICE.type == "cuda"),
)

labels_all = []
scores_all = []

with torch.no_grad():
    for features, labels in loader:
        logits = model(features.to(DEVICE))
        scores = torch.sigmoid(logits).cpu().numpy()

        labels_all.extend(labels.numpy())
        scores_all.extend(scores)

labels = np.asarray(labels_all, dtype=int)
scores = np.asarray(scores_all)

print("Checkpoint epoch:", checkpoint["epoch"])
print("Validation samples:", len(labels))
print("Labels present:", np.unique(labels, return_counts=True))

for label, name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
    class_scores = scores[labels == label]
    print(f"\n{name}:")
    print("  Count:", len(class_scores))
    print("  Mean score:", round(float(class_scores.mean()), 4))
    print("  Median score:", round(float(np.median(class_scores)), 4))
    print("  Min / max:", round(float(class_scores.min()), 4),
          "/", round(float(class_scores.max()), 4))
    print("  Fraction scoring >= 0.5:",
          round(float((class_scores >= 0.5).mean()), 4))

auc = roc_auc_score(labels, scores)
inverse_auc = roc_auc_score(labels, 1.0 - scores)

print("\nAUC using current scores:", round(auc, 4))
print("AUC using inverted scores:", round(inverse_auc, 4))
