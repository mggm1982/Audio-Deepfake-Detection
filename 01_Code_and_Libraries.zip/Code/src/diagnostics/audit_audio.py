# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

import csv
import random
from pathlib import Path

import soundfile as sf

ROOT = PROJECT_ROOT
MANIFEST_DIR = ROOT / "Manifests"
random.seed(42)

manifests = [
    "asvspoof_train.csv",
    "itw_train.csv",
    "itw_val.csv",
    "itw_test.csv",
]

for manifest_name in manifests:
    manifest = MANIFEST_DIR / manifest_name

    print("\n" + "=" * 70)
    print(manifest_name)

    if not manifest.exists():
        print(f"ERROR: Manifest not found: {manifest}")
        continue

    with manifest.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    groups = {}
    for row in rows:
        groups.setdefault(int(row["label"]), []).append(row)

    for label, label_name in [(1, "REAL"), (0, "FAKE/SPOOF")]:
        group = groups.get(label, [])
        print(f"\n{label_name}: {len(group):,} indexed files")

        for row in random.sample(group, min(5, len(group))):
            path = Path(row["file_path"])

            try:
                info = sf.info(str(path))
                print(
                    f"  {path.name}: "
                    f"{info.samplerate} Hz, "
                    f"{info.channels} channel(s), "
                    f"{info.duration:.2f} sec"
                )
            except Exception as e:
                print(f"  ERROR: {path} -- {e}")
