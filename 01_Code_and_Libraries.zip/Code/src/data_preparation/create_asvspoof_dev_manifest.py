# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

from pathlib import Path
import csv
from collections import Counter

ASV_ROOT = ROOT / "Testing Data" / "ASVspoof2019_LA"
PROTOCOL = ASV_ROOT / "ASVspoof2019_LA_cm_protocols" / "ASVspoof2019.LA.cm.dev.trl.txt"
AUDIO_DIR = ASV_ROOT / "ASVspoof2019_LA_dev" / "flac"
OUTPUT = ROOT / "Manifests" / "asvspoof_dev.csv"

OUTPUT.parent.mkdir(parents=True, exist_ok=True)

counts = Counter()
missing = []
rows = []

with PROTOCOL.open(encoding="utf-8") as f:
    for line_number, line in enumerate(f, start=1):
        parts = line.split()

        if len(parts) < 5:
            print(f"Skipping malformed line {line_number}: {line.strip()}")
            continue

        speaker_id, file_id = parts[0], parts[1]
        protocol_label = parts[-1].lower()

        if protocol_label not in {"bonafide", "spoof"}:
            print(f"Skipping unknown label on line {line_number}")
            continue

        label = 1 if protocol_label == "bonafide" else 0
        audio_path = AUDIO_DIR / f"{file_id}.flac"

        if not audio_path.is_file():
            missing.append(str(audio_path))
            continue

        rows.append({
            "file_path": str(audio_path),
            "label": label,
            "split": "dev",
            "source": "asvspoof2019_la_dev",
        })
        counts[label] += 1

with OUTPUT.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(
        f, fieldnames=["file_path", "label", "split", "source"]
    )
    writer.writeheader()
    writer.writerows(rows)

print(f"\nManifest: {OUTPUT}")
print(f"Total audio files found: {len(rows)}")
print(f"Real / bonafide (1): {counts[1]}")
print(f"Fake / spoof (0): {counts[0]}")
print(f"Missing audio files: {len(missing)}")

if missing:
    print("First missing paths:")
    for path in missing[:10]:
        print(" ", path)
