# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

import csv
import random
import shutil
import tarfile
from pathlib import Path, PurePosixPath
import re

import requests
from remotezip import RemoteZip

ARCHIVE_PATH = ROOT / "Additional Evaluation Data" / "WaveFake" / "LJSpeech-1.1.tar.bz2"
OUT = ROOT / "Additional Evaluation Data" / "WaveFake" / "wavefake_benchmark"
SAMPLE_SIZE = 100
SEED = 42

GENERATORS = [
    "ljspeech_hifiGAN",
    "ljspeech_parallel_wavegan",
    "ljspeech_full_band_melgan",
    "ljspeech_melgan",
    "ljspeech_waveglow",
    "ljspeech_multi_band_melgan",
    "ljspeech_melgan_large",
]

ID_PATTERN = re.compile(
    r"^(LJ\d{3}-\d{4})(?:_generated|_gen)?\.wav$", re.I
)

if not ARCHIVE_PATH.exists():
    raise FileNotFoundError(f"Missing archive: {ARCHIVE_PATH}")

response = requests.get(
    "https://zenodo.org/api/records/5642694", timeout=30
)
response.raise_for_status()
record = response.json()

zip_url = next(
    item["links"]["self"]
    for item in record["files"]
    if item["key"].endswith("generated_audio.zip")
)

OUT.mkdir(parents=True, exist_ok=True)
real_dir = OUT / "real"
real_dir.mkdir(exist_ok=True)

print("Inspecting remote ZIP and selecting matched utterances...")

with RemoteZip(zip_url) as archive:
    names = archive.namelist()
    mappings = {}

    for generator in GENERATORS:
        prefix = f"generated_audio/{generator}/"
        mapping = {}

        for name in names:
            if not name.startswith(prefix):
                continue
            filename = PurePosixPath(name).name
            match = ID_PATTERN.fullmatch(filename)
            if match:
                utterance_id = match.group(1).upper()
                mapping[utterance_id] = name

        mappings[generator] = mapping
        print(f"{generator}: {len(mapping):,} matched filenames")

    common_ids = set.intersection(
        *(set(mapping) for mapping in mappings.values())
    )

    if len(common_ids) < SAMPLE_SIZE:
        raise RuntimeError(
            f"Only {len(common_ids)} shared IDs; need {SAMPLE_SIZE}."
        )

    selected = sorted(common_ids)
    random.Random(SEED).shuffle(selected)
    selected = sorted(selected[:SAMPLE_SIZE])

    print(f"\nSelected {len(selected)} utterances.")
    print("Downloading only the selected audio files...")

    manifest_path = OUT / "pairs.csv"
    rows = []

    with tarfile.open(ARCHIVE_PATH, "r:bz2") as tar:
        tar_members = None

        for index, utterance_id in enumerate(selected, 1):
            original_name = f"LJSpeech-1.1/wavs/{utterance_id}.wav"
            target_real = real_dir / f"{utterance_id}.wav"

            if not target_real.exists():
                try:
                    member = tar.getmember(original_name)
                except KeyError:
                    print(f"WARNING: Missing original: {original_name}")
                    continue

                source = tar.extractfile(member)
                if source is None:
                    print(f"WARNING: Cannot extract {original_name}")
                    continue

                with source, target_real.open("wb") as dest:
                    shutil.copyfileobj(source, dest)

            for generator in GENERATORS:
                zip_member = mappings[generator][utterance_id]
                generator_dir = OUT / "generated" / generator
                generator_dir.mkdir(parents=True, exist_ok=True)
                target_fake = (
                    generator_dir / f"{utterance_id}_generated.wav"
                )

                if not target_fake.exists():
                    with archive.open(zip_member) as source:
                        with target_fake.open("wb") as dest:
                            shutil.copyfileobj(source, dest)

                rows.append({
                    "utterance_id": utterance_id,
                    "generator": generator,
                    "real_path": str(target_real.relative_to(ROOT)),
                    "fake_path": str(target_fake.relative_to(ROOT)),
                })

            if index % 10 == 0 or index == len(selected):
                print(f"Processed {index}/{len(selected)} utterances")

    with manifest_path.open("w", newline="") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "utterance_id", "generator", "real_path", "fake_path"
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

print(f"\nManifest: {manifest_path.relative_to(ROOT)}")
print(f"Matched pairs: {len(rows)}")
print("\nPreparation complete.")
