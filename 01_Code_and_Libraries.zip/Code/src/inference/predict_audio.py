# Repository path bootstrap: scripts can be run directly from the project root.
from pathlib import Path as _Path
import sys as _sys
PROJECT_ROOT = _Path(__file__).resolve().parents[3]
ROOT = PROJECT_ROOT
SRC_ROOT = PROJECT_ROOT / "Code" / "src"
if str(SRC_ROOT) not in _sys.path:
    _sys.path.insert(0, str(SRC_ROOT))

from pathlib import Path
import numpy as np
import soundfile as sf
import librosa
import torch
import torch.nn.functional as F

from training.train_cnn import (
    SR, NUM_SAMPLES, N_FFT, HOP_LENGTH,
    MEL_FILTER, WINDOW, AudioCNN, DEVICE, ROOT,
)

CHECKPOINT = ROOT / "Model Weights" / "best_cnn_mixed.pt"
AUDIO_DIR = ROOT / "Testing Data" / "User Audio"

FILES = [
    "my_real_voice_original.wav",
    "my_ai_voice.wav",
]

def load_audio(path):
    audio, sr = sf.read(str(path), dtype="float32")

    if audio.ndim == 2:
        audio = audio.mean(axis=1)

    if sr != SR:
        audio = librosa.resample(
            audio, orig_sr=sr, target_sr=SR
        ).astype(np.float32)

    return audio

def extract_features(segment):
    segment = torch.from_numpy(np.asarray(segment, dtype=np.float32))

    if len(segment) < NUM_SAMPLES:
        segment = F.pad(segment, (0, NUM_SAMPLES - len(segment)))

    spec = torch.stft(
        segment,
        n_fft=N_FFT,
        hop_length=HOP_LENGTH,
        win_length=N_FFT,
        window=WINDOW,
        center=True,
        pad_mode="reflect",
        return_complex=True,
    ).abs().square()

    mel = MEL_FILTER @ spec
    log_mel = 10.0 * torch.log10(mel.clamp_min(1e-10))
    log_mel = log_mel - log_mel.max()
    log_mel = log_mel.clamp(min=-80.0, max=0.0)

    features = ((log_mel + 40.0) / 40.0).unsqueeze(0)
    return features.unsqueeze(0).to(DEVICE)

def main():
    model = AudioCNN().to(DEVICE)
    checkpoint = torch.load(
        CHECKPOINT, map_location=DEVICE, weights_only=False
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print(f"Device: {DEVICE}")
    print(f"Checkpoint epoch: {checkpoint.get('epoch', 'unknown')}")
    print("Window length: 4 seconds; stride: 1 second")

    with torch.no_grad():
        for name in FILES:
            path = AUDIO_DIR / name
            if not path.is_file():
                print(f"\nMissing file: {path}")
                continue

            audio = load_audio(path)
            duration = len(audio) / SR

            # Evaluate each complete 4-second window.
            if len(audio) < NUM_SAMPLES:
                starts = [0]
            else:
                last_start = len(audio) - NUM_SAMPLES
                starts = list(range(0, last_start + 1, SR))
                if starts[-1] != last_start:
                    starts.append(last_start)

            scores = []
            print(f"\n--- {name} ({duration:.2f}s) ---")

            for start in starts:
                segment = audio[start:start + NUM_SAMPLES]
                score = torch.sigmoid(model(extract_features(segment))).item()
                scores.append(score)
                print(
                    f"Window {start / SR:5.2f}-{(start + len(segment)) / SR:5.2f}s"
                    f" | real-class score: {score:.6f}"
                )

            print(f"Mean window score:   {np.mean(scores):.6f}")
            print(f"Median window score: {np.median(scores):.6f}")
            print("Note: scores are model outputs, not calibrated probabilities.")

if __name__ == "__main__":
    main()
